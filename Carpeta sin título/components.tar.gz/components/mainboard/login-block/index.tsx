import styles from './styles.module.css'
import mainStyles from '../styles.module.css'
import Link from "next/link"

export default function LoginBlock() {
    return (
        <div className={mainStyles.boardSection}>
            <div className={styles.lemma}>
                <p>start <span className={styles.resalted}>streaming</span> games differently</p>
            </div>
            <div className={styles.notice}>
                <p>gamor now has <span className={styles.underlined}>stream party</span> platform</p>
            </div>
            <div className={styles.access}>
                <button className={styles.btnRoundWhite}>
                    <Link href='/sign-up'>Create account</Link>
                </button>
                <button className={mainStyles.link}>
                    <Link href='/sign-in'>Sign in</Link>
                </button>
            </div>
        </div>
    )
}