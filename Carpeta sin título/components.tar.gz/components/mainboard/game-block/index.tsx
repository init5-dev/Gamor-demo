import styles from './styles.module.css'

import { Room } from '@/libs/gameroom'
import UserBall from '../userball'
import Clock from '../clock'

export default function GameBlock(
    {game, joinedRoom, added, searchResults, userState, imgStyle}:
    {
        game: string, 
        joinedRoom: Room[] | null, 
        added: boolean, 
        searchResults: Room[], 
        userState: {
            isLoaded: boolean,
            isSignedIn: boolean | undefined,
            user: any
        },
        imgStyle: React.CSSProperties
    }
    ) {

    return (
        <div className={styles.boardSectionWithBg}>
                <div className={styles.bgImage} style={imgStyle}>
                    <div className={styles.ad}>
                        <p className={styles.adTitle}>{game}</p>
                        <p className={styles.adSubtitle}>Join Live {searchResults.length ? searchResults[0].platform : '!'}</p>
                    </div>
                    <div className={styles.clockSection}>
                        {
                            userState.isLoaded && userState.isSignedIn && userState.user && <div className={styles.userBallSection}>
                                {
                                    joinedRoom && <UserBall added={added && joinedRoom[0]?.game.name === game} />
                                }
                            </div>
                        }
                        <Clock />
                    </div>
                </div>
            </div>
    )
}