import styles from './styles.module.css'
import mainStyles from '../styles.module.css'

import { useState } from 'react'

import { Room } from '@/libs/gameroom'
import { ISelectOption } from '@/libs/interfaces'
import SelectPlatform from './select-platform'
import SearchBox from './search-game/search-box'

export default function GameBlock({ rooms }: { rooms: Room[] }) {

    const [platform, setPlatform] = useState('Party')
    const [search, setSearch] = useState("")
    const [searchResults, setSearchResults] = useState<Room[]>([])
    
   


    return (
        <div className={styles.boardSection}>
            <SelectPlatform platform={platform} setPlatform={setPlatform} />
            <SearchBox setSearch={setSearch} setSearchResults={setSearchResults} />
        </div>
    )
}