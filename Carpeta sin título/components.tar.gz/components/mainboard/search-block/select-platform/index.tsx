import styles from './styles.module.css'
import { MouseEvent } from 'react'

export default function SelectPlatform({platform, setPlatform}: {platform: string, setPlatform: (platform: string) => void}) {

    function selectPlatform(e: MouseEvent<HTMLElement>) {
        setPlatform(e.currentTarget.innerText)
    }

    return (
        <div>
            <div>
                <span className={styles.stepNum}>01.</span>
                <span className={styles.stepCont}><strong>Choose</strong> Platform</span>
            </div>
            <div className={styles.tabsPane}>
                <button className={styles.tab + (platform === 'Party' ? ' ' + styles.tabActive : '')} onClick={selectPlatform}>Party</button>
                <button className={styles.tab + (platform === 'Match' ? ' ' + styles.tabActive : '')} onClick={selectPlatform}>Match</button>
                <button className={styles.tab + (platform === 'Streams' ? ' ' + styles.tabActive : '')} onClick={selectPlatform}>Streams</button>
            </div>
        </div>
    )
}