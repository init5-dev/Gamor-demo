import styles from './styles.module.css'

import { useState } from "react"
import Image from "next/image"

import { Room } from "@/libs/gameroom"
import Alert from "../alert"

export default function SearchList(
    { isSignedIn, rooms, searchResults, game, joinedRoom, setJoinedRoom, setAdded }: 
    { 
        isSignedIn: boolean, 
        rooms: Room[], 
        searchResults: Room[],
        game: string,
        joinedRoom: Room[] | null,
        setJoinedRoom: (value: Room[] | null) => void,
        setAdded: (value: boolean) => void 
    }
    ) {

    const [attention, setAttention] = useState({
        active: false,
        message: ''
    })

    function addUser(e: React.MouseEvent<HTMLElement>) {

        if (!isSignedIn) {
            setAttention({
                active: true,
                message: 'Please log in to join',
            })
            return
        }

        if (joinedRoom) {
            if (joinedRoom[0].name.indexOf(e.currentTarget.id) < 0) {
                return
            }

            if (e.currentTarget.textContent === '-' && joinedRoom[0]?.game.name === game) {
                setAdded(false)
                setJoinedRoom(null)
                setAttention({
                    active: true,
                    message: 'Bye!'
                })
                return
            }
        }

        const roomToJoin = rooms.filter(
            (room) => {
                console.log("room.name: " + room.name)
                console.log("e.currentTarget.id: " + e.currentTarget.id)
                return room.name.indexOf(e.currentTarget.id) > -1
            }
        )
        console.log(roomToJoin)
        setJoinedRoom(roomToJoin)

        if (roomToJoin.length) {
            setAdded(true)
            e.currentTarget.textContent = '-'
            setAttention({
                active: true,
                message: 'You have joined ' + roomToJoin[0].name
            })
            return
        }
    }

    return (
        <div className={styles.gamesList}>
            {
                attention.active && <Alert message={attention.message} onClose={() => setAttention({ active: false, message: '' })} />
            }
            {
                searchResults.length ? searchResults.map(
                    (room, i) => <div key={room.name} className={styles.gamesListRow}>
                        <span className={styles.roomNumber}>{i}</span>
                        <strong className={styles.roomName}>{room.name}</strong>
                        {
                            room.members.map(
                                (member) => <Image className={styles.listAvatar} key={member} src={`/users/${member}.png`} width={24} height={24} alt={`Avatar de ${member}`} />
                            )
                        }
                        <button id={room.name} className={styles.btnAdd} onClick={addUser}>{joinedRoom ? (joinedRoom[0]?.game.name === game ? '-' : '+') : '+'}</button>
                    </div>
                ) : <div className={styles.nothingHere}>Nothing here!</div>
            }
        </div>
    )
}