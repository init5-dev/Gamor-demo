import styles from './styles.module.css'

import { useState } from 'react'
import Select, { SingleValue, ActionMeta, InputActionMeta } from 'react-select'

import { Equalizer } from '@styled-icons/remix-line/'
import FilterPopup from '../../filter-popup'
import { ISelectOption } from '@/libs/interfaces'
import { Room } from '@/libs/gameroom'

const roomStates = ['active', 'inactive', 'all']
const defState = { label: 'all', value: 'all' }
const availableLangs = ['en', 'es', 'ch', 'fr', 'it', 'all']
const defLang = { label: 'all', value: 'all' }

export default function SearchBox(
    {setSearch, setSearchResults }:
        {
            setSearch: (value: string) => void,
            setSearchResults: (value: Room[]) => void
        }
) {

    const [showFilter, setShowFilter] = useState(false)
    const [imgPath, setImgPath] = useState('')

    const [imgStyle, setImgStyle] = useState<React.CSSProperties>(
        {
            backgroundImage: `url('../../public/media/call-of-duty-cover-portrait.jpg')`,
            height: `100%`,
            width: `100%`,
            backgroundSize: `cover`,
            backgroundRepeat: `none`,
            padding: `32px`,
        }
    )

    const [state, setState] = useState<string>("all")
    const [states, setStates] = useState<ISelectOption[]>([])

    const [language, setLanguage] = useState<string>("all")
    const [languages, setLanguages] = useState<ISelectOption[]>([])

    const [game, setGame] = useState<string>('')
    const [games, setGames] = useState<ISelectOption[]>([])



    function handleChange(newValue: SingleValue<ISelectOption>, actionMeta: ActionMeta<ISelectOption>) {

        if (!newValue) {
            return
        }

        setSearch(newValue.label)
        setImgPath('/media/' + newValue.label + '.jpg')
        updateImgStyle()
        setGame(newValue.label)
        setSearchResults([])

    }

    function handleInputChange(newValue: string, actionMeta: InputActionMeta) {
        if (!newValue) {
            return
        }
        setSearch(newValue)
        const tmp = "" + imgPath
        setImgPath('/media/' + newValue + '.jpg')
        updateImgStyle()
        setGame(newValue)
        setSearchResults([])
    }

    function getFilters(stateArg: string | undefined = undefined, languageArg: string | undefined = undefined) {
        if (stateArg) {
            setState(stateArg)
        }
        if (languageArg) {
            setLanguage(languageArg)
        }
    }

    function updateImgStyle() {
        const imgstyle: React.CSSProperties = {
            backgroundImage: `url('${imgPath}')`,
            height: `100%`,
            width: `100%`,
            backgroundSize: `cover`,
            backgroundRepeat: `none`,
            padding: `32px`,
        }
        setImgStyle(imgstyle)
        console.log('IMAGE PATH: ' + imgPath)
    }

    return (
        <>
            <div className={styles.searchHeader}>
                <Select id='searchbox' options={games} className={styles.searchBox} placeholder={games && games.length ? games[0].label : ''} onChange={handleChange} onInputChange={handleInputChange} />
                <div className={styles.filtersContainer}>
                    <button onClick={() => { setShowFilter(!showFilter) }}>
                        <Equalizer className={styles.filterBtn} width={24} height={24} style={{ color: `val(--dark)` }} />
                    </button>
                </div>
            </div>
            {
                showFilter && <FilterPopup
                    languages={languages}
                    states={states}
                    defaultLanguage={{ label: language, value: language }}
                    defaultState={{ label: state, value: state }}
                    onEdit={getFilters}
                    onClose={() => setShowFilter(false)}
                />
            }
        </>
    )
}