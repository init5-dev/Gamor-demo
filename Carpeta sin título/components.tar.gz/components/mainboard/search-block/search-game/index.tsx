import styles from './styles.module.css'

import Image from 'next/image'
import { useState, useEffect, MouseEvent } from 'react'

import SearchBox from './search-box'
import SearchList from './search-list'
import { Room } from '@/libs/gameroom'

export default function SelectGame({ games }) {

    const [search, setSearch] = useState("")
    const [searchResults, setSearchResults] = useState<Room[]>([])

    const [added, setAdded] = useState<boolean>(false)
    const [joinedRoom, setJoinedRoom] = useState<Room[] | null>(null)

    const [imgPath, setImgPath] = useState('')
    const [attention, setAttention] = useState({
        active: false,
        message: ''
    })

    const [imgStyle, setImgStyle] = useState<React.CSSProperties>(
        {
            backgroundImage: `url('../../public/media/call-of-duty-cover-portrait.jpg')`,
            height: `100%`,
            width: `100%`,
            backgroundSize: `cover`,
            backgroundRepeat: `none`,
            padding: `32px`,
        }
    )

    useEffect(
        () => {
            const games: ISelectOption[] = []

            rooms.forEach(
                (room) => {
                    games.push(
                        {
                            label: room.game.name,
                            value: room.game.name
                        }
                    )
                }
            )
            setGames(games.sort(
                (a, b) => {
                    if (a.label < b.label) { return -1; }
                    if (a.label > b.label) { return 1; }
                    return 0;
                }
            ))

            const states: ISelectOption[] = []
            const languages: ISelectOption[] = []

            for (let item of roomStates) {
                states.push({
                    label: item,
                    value: item
                })
            }

            for (let item of availableLangs) {
                languages.push({
                    label: item,
                    value: item
                })
            }

            setStates(states)
            setLanguages(languages)
            setImgPath('/media/' + games[0].label + '.jpg')
            setGame(games[0].label)
        },
        []
    )

    useEffect(
        () => {
            updateImgStyle()
        },
        [imgPath]
    )



    function searchGame() {
        console.log("SEARCH: " + JSON.stringify(search))

        if (search.length) {
            const res = rooms.filter(
                (room) => (room.game.name.includes(search) || search.trim() === "") && room.platform === platform && (room.state === state || state === "all") && (room.language === language || language === "all")
            )
            setSearchResults(res)
            console.log("STATE: " + state)
            console.log("LANG: " + language)
            console.log("RESULT: " + JSON.stringify(res))
        }
    }

    return (
        <div>
            <div>
                <span className={styles.stepNum}>02.</span>
                <span className={styles.stepCont}><strong>Searching</strong> Game</span>
            </div>
            <div className={styles.searchContainer}>
                <SearchBox />
                <SearchList />
                <div>
                    <button
                        className={search ? styles.btnRectDark : styles.btnRectDarkDisabled}
                        disabled={search ? false : true}
                        onClick={searchGame}
                    >
                        Search Now
                    </button>
                </div>
            </div>
        </div>
    )
}