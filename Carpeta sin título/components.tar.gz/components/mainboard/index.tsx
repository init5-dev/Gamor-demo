'use client'

import styles from './styles.module.css'
import Image from 'next/image'
import { ChangeEvent, useEffect, useState } from 'react'
import { Room, Game } from '@/libs/gameroom'
import Select from 'react-select'
import { ISelectOption } from '@/libs/interfaces'
import { SingleValue, ActionMeta, InputActionMeta } from 'react-select'
import FilterPopup from './search-block/filter-popup/filterPopup'
import Link from 'next/link'
import Clock from './clock'
import UserBall from './userball'
import { useUser } from '@clerk/nextjs'
import Alert from './search-block/search-game/alert'
import LoginBlock from './login-block'
import GameBlock from './game-block'

export default function MainBoard({ rooms }: { rooms: Room[] }) {

    const [game, setGame] = useState<string>('')
    const [added, setAdded] = useState<boolean>(false)
    const [joinedRoom, setJoinedRoom] = useState<Room[] | null>(null)
    const [searchResults, setSearchResults] = useState<Room[]>([])

    const [imgStyle, setImgStyle] = useState<React.CSSProperties>(
        {
            backgroundImage: `url('../../public/media/call-of-duty-cover-portrait.jpg')`,
            height: `100%`,
            width: `100%`,
            backgroundSize: `cover`,
            backgroundRepeat: `none`,
            padding: `32px`,
        }
    )

    const { isLoaded, isSignedIn, user } = useUser();


    return (
        <div className={styles.mainBoard}>
            <LoginBlock />
            <GameBlock
                game={game}
                joinedRoom={joinedRoom}
                added={added}
                searchResults={searchResults}
                userState={{
                    isLoaded: isLoaded,
                    isSignedIn: isSignedIn,
                    user: user
                }}
                imgStyle={imgStyle}
            />
        </div>
    )
}